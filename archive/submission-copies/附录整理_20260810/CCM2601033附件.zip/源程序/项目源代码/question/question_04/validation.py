"""问题4验证入口。检验模型假设、拟合结果和稳健性。"""

from __future__ import annotations

import logging
from pathlib import Path


QUESTION_DIR = Path(__file__).resolve().parent
TABLES_DIR = QUESTION_DIR / "outputs" / "tables"


def main() -> int:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)s | %(message)s", force=True)
    if not any(path.is_file() for path in TABLES_DIR.iterdir()):
        logging.info("没有模型结果表，跳过验证。")
        return 0
    logging.error("已有模型结果，但尚未配置本题验证方案。")
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
