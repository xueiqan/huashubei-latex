# 本程序及代码是在 AI 工具辅助下完成的。
# AI 工具名称：DeepSeek，版本/型号：DeepSeek-V4-Flash-0731，开发机构/公司：深度求索（DeepSeek），版本发布日期：2026-07-31。

"""问题4结果绘图。

读取Q4结果表和共享参数，输出三组图；缺少结果表时在对应面板标记待补。
"""

from __future__ import annotations

import logging
from pathlib import Path

import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.colors import LinearSegmentedColormap, TwoSlopeNorm


QUESTION_DIR = Path(__file__).resolve().parent
PROJECT_DIR = QUESTION_DIR.parents[1]
TABLES_DIR = QUESTION_DIR / "outputs" / "tables"
FIGURES_DIR = QUESTION_DIR / "outputs" / "figures"
SHARED_DIR = PROJECT_DIR / "question" / "question_01" / "data" / "processed" / "shared"

MAIN_END_HOUR = 2406

REGION_ORDER = (
    "RegionA",
    "RegionB",
    "RegionC",
    "RegionD",
    "RegionE",
    "RegionF",
)

METRICS = ("Cost", "Carbon", "Latency", "Delay", "RenewableUnusedRate", "Peak")
METRIC_LABELS = {
    "Cost": "C",
    "Carbon": "E",
    "Latency": "L",
    "Delay": "J",
    "RenewableUnusedRate": "Q",
    "Peak": "P",
}

SCENARIO_METRICS = ("Cost", "Carbon", "Latency", "QoS", "Utilization", "Peak")
SCENARIO_LABELS = {
    "Cost": "C",
    "Carbon": "E",
    "Latency": "L",
    "QoS": "QoS",
    "Utilization": "U",
    "Peak": "P",
}

PALETTE = {
    "series_blue": "#5773cc",
    "series_gold": "#ffb900",
    "series_cyan": "#23bac5",
    "series_orange": "#fd763f",
    "series_green": "#43b284",
    "series_deep_blue": "#0f7ba2",
    "text": "#003967",
    "grid": "#acd6ec",
    "reference": "#d77071",
    "neutral": "#7f8c8d",
    "white": "#ffffff",
}

REGION_COLORS = {
    "RegionA": PALETTE["series_blue"],
    "RegionB": PALETTE["series_gold"],
    "RegionC": PALETTE["series_cyan"],
    "RegionD": PALETTE["series_orange"],
    "RegionE": PALETTE["series_deep_blue"],
    "RegionF": PALETTE["series_green"],
}

SCENARIO_CMAP = LinearSegmentedColormap.from_list(
    "q4_scenario_diverging",
    [PALETTE["series_blue"], PALETTE["white"], PALETTE["series_orange"]],
)


def _configure_style() -> None:
    plt.rcParams.update(
        {
            "font.family": "sans-serif",
            "font.sans-serif": ["Microsoft YaHei", "SimHei", "DejaVu Sans"],
            "axes.unicode_minus": False,
            "text.color": PALETTE["text"],
            "axes.edgecolor": PALETTE["text"],
            "axes.labelcolor": PALETTE["text"],
            "axes.titlecolor": PALETTE["text"],
            "axes.labelsize": 8.2,
            "axes.titlesize": 9.0,
            "xtick.color": PALETTE["text"],
            "ytick.color": PALETTE["text"],
            "xtick.labelsize": 7.0,
            "ytick.labelsize": 7.0,
            "legend.fontsize": 6.6,
            "figure.facecolor": PALETTE["white"],
            "axes.facecolor": PALETTE["white"],
            "savefig.facecolor": PALETTE["white"],
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
        }
    )


def _read_csv(path: Path, required: tuple[str, ...] = ()) -> pd.DataFrame | None:
    if not path.is_file():
        return None
    try:
        frame = pd.read_csv(path, encoding="utf-8-sig")
    except (OSError, UnicodeError, pd.errors.ParserError, ValueError) as exc:
        logging.warning("图表输入读取失败：%s；%s", path, exc)
        return None
    missing = [column for column in required if column not in frame.columns]
    if missing:
        logging.warning("%s缺少字段：%s", path.name, missing)
        return None
    return frame


def _read_table(filename: str, required: tuple[str, ...] = ()) -> pd.DataFrame | None:
    path = TABLES_DIR / filename
    frame = _read_csv(path, required)
    if frame is None and not path.is_file():
        logging.info("图表输入待补：%s", path.name)
    return frame


def _numeric(frame: pd.DataFrame, columns: tuple[str, ...] | list[str]) -> pd.DataFrame:
    result = frame.copy()
    for column in columns:
        if column in result.columns:
            result[column] = pd.to_numeric(result[column], errors="coerce")
    return result


def _norm_token(value: object) -> str:
    return "".join(character.lower() for character in str(value) if character.isalnum())


def _find_column(frame: pd.DataFrame, aliases: tuple[str, ...]) -> str | None:
    normalized = {_norm_token(column): column for column in frame.columns}
    for alias in aliases:
        column = normalized.get(_norm_token(alias))
        if column is not None:
            return column
    return None


def _first_existing(names: tuple[str, ...]) -> Path | None:
    for name in names:
        path = TABLES_DIR / name
        if path.is_file():
            return path
    return None


def _style_axis(axis: plt.Axes, grid_axis: str = "y") -> None:
    if grid_axis == "none":
        axis.grid(False)
    else:
        axis.grid(True, axis=grid_axis, color=PALETTE["grid"], linewidth=0.65, alpha=0.72)
    axis.set_axisbelow(True)
    axis.tick_params(axis="both", colors=PALETTE["text"], labelcolor=PALETTE["text"])
    for spine in axis.spines.values():
        spine.set_color(PALETTE["text"])
        spine.set_linewidth(0.72)
    axis.spines["top"].set_visible(False)
    axis.spines["right"].set_visible(False)


def _legend(axis: plt.Axes, **kwargs) -> None:
    legend = axis.legend(frameon=False, **kwargs)
    if legend is not None:
        for text in legend.get_texts():
            text.set_color(PALETTE["text"])


def _panel_caption(axis: plt.Axes, text: str, y: float = -0.22) -> None:
    axis.text(
        0.5,
        y,
        text,
        transform=axis.transAxes,
        ha="center",
        va="top",
        fontsize=8.3,
        fontweight="bold",
        color=PALETTE["text"],
        clip_on=False,
    )


def _validation_placeholder(axis: plt.Axes, message: str, detail: str) -> None:
    axis.set_xlim(0, 1)
    axis.set_ylim(0, 1)
    axis.set_xticks([])
    axis.set_yticks([])
    for spine in axis.spines.values():
        spine.set_visible(False)
    axis.text(
        0.5,
        0.58,
        message,
        ha="center",
        va="center",
        fontsize=9.0,
        fontweight="bold",
        color=PALETTE["text"],
    )
    axis.text(
        0.5,
        0.38,
        detail,
        ha="center",
        va="center",
        fontsize=6.7,
        color=PALETTE["reference"],
        wrap=True,
    )


def _save(figure: plt.Figure, stem: str) -> bool:
    """同时输出PDF和450dpi PNG预览。"""
    FIGURES_DIR.mkdir(parents=True, exist_ok=True)
    pdf_path = FIGURES_DIR / f"{stem}.pdf"
    png_path = FIGURES_DIR / f"{stem}.png"
    try:
        try:
            figure.savefig(pdf_path, format="pdf", bbox_inches="tight", pad_inches=0.06)
        except PermissionError:
            fallback = FIGURES_DIR / f"{stem}_new.pdf"
            figure.savefig(fallback, format="pdf", bbox_inches="tight", pad_inches=0.06)
            logging.warning("%s被占用，PDF改写为%s。", pdf_path.name, fallback.name)
        figure.savefig(png_path, format="png", dpi=450, bbox_inches="tight", pad_inches=0.06)
    except OSError as exc:
        logging.error("图表保存失败：%s；%s", stem, exc)
        return False
    finally:
        plt.close(figure)
    logging.info("图表已写出：%s、%s。", pdf_path, png_path)
    return True


def _choose_row(frame: pd.DataFrame, preferred_tokens: tuple[str, ...]) -> pd.Series:
    if frame.empty:
        return pd.Series(dtype=object)
    scheme_column = _find_column(frame, ("Scheme", "Solution", "Scenario", "Case", "Name"))
    if scheme_column is not None:
        labels = frame[scheme_column].astype(str)
        for token in preferred_tokens:
            mask = labels.str.contains(token, case=False, regex=False, na=False)
            if mask.any():
                return frame.loc[mask].iloc[0]
    return frame.iloc[0]


def _canonical_q4_metric(value: object) -> str | None:
    token = _norm_token(value)
    aliases = {
        "cost": "Cost",
        "operatingcost": "Cost",
        "operatingcostcny": "Cost",
        "carbon": "Carbon",
        "carbonemission": "Carbon",
        "carbonemissiontco2": "Carbon",
        "latency": "Latency",
        "meannetworklatency": "Latency",
        "meannetworklatencyms": "Latency",
        "delay": "Delay",
        "servicequalityloss": "Delay",
        "renewableunusedrate": "RenewableUnusedRate",
        "q": "RenewableUnusedRate",
        "peak": "Peak",
        "peaknetgridimport": "Peak",
        "peaknetgridimportmw": "Peak",
    }
    return aliases.get(token)


def _metrics_from_frame(
    frame: pd.DataFrame,
    preferred_tokens: tuple[str, ...] = (),
) -> dict[str, float] | None:
    """兼容Q4长表和一行宽表，不对缺失指标进行补值。"""
    result: dict[str, float] = {}
    metric_column = _find_column(frame, ("Metric", "Objective", "Indicator"))
    value_column = _find_column(frame, ("Value", "MetricValue", "Result", "ObjectiveValue"))
    if metric_column is not None and value_column is not None:
        for row in frame.itertuples(index=False):
            raw_metric = getattr(row, metric_column)
            metric = _canonical_q4_metric(raw_metric)
            if metric is None:
                continue
            try:
                value = float(getattr(row, value_column))
            except (TypeError, ValueError):
                continue
            if np.isfinite(value):
                result[metric] = value
    if set(result) == set(METRICS):
        return result

    row = _choose_row(frame, preferred_tokens)
    if row.empty:
        return None
    aliases = {
        "Cost": ("Cost", "OperatingCost_CNY", "OperatingCost"),
        "Carbon": ("Carbon", "CarbonEmission_tCO2", "CarbonEmission"),
        "Latency": ("Latency", "MeanNetworkLatency_ms", "MeanNetworkLatency"),
        "Delay": ("Delay", "ServiceQualityLoss", "J"),
        "RenewableUnusedRate": ("RenewableUnusedRate", "Q"),
        "Peak": ("Peak", "PeakNetGridImport_MW", "PeakNetGridImport"),
    }
    for metric, candidates in aliases.items():
        column = _find_column(frame, candidates)
        if column is None:
            continue
        try:
            value = float(row[column])
        except (TypeError, ValueError):
            continue
        if np.isfinite(value):
            result[metric] = value
    return result if set(result) == set(METRICS) else None


def _load_q4_objective_metrics() -> dict[str, float] | None:
    frame = _read_table("q4_objective_summary.csv", ("Metric", "Value"))
    if frame is None:
        return None
    frame = _numeric(frame, ["Value"])
    values = _metrics_from_frame(frame, ("Q4JointRolling", "Q4", "Joint"))
    if values is None:
        logging.warning("q4_objective_summary.csv未形成完整六目标指标。")
    return values


def _load_scaling() -> dict[str, tuple[float, float]] | None:
    frame = _read_table("q4_scaling.csv", ("Metric", "Anchor", "Scale"))
    if frame is None:
        return None
    frame = _numeric(frame, ["Anchor", "Scale"])
    result: dict[str, tuple[float, float]] = {}
    for row in frame.itertuples(index=False):
        metric = _canonical_q4_metric(row.Metric)
        if metric is None:
            continue
        anchor = float(row.Anchor)
        scale = float(row.Scale)
        if np.isfinite(anchor) and np.isfinite(scale) and scale > 0:
            result[metric] = (anchor, scale)
    return result if set(result) == set(METRICS) else None


SEQUENTIAL_METRIC_FILES = (
    "q4_sequential_objective_summary.csv",
    "q4_sequence_objective_summary.csv",
    "q4_sequential_summary.csv",
    "q4_sequential_baseline.csv",
)


def _load_sequential_metrics() -> tuple[dict[str, float], str] | None:
    path = _first_existing(SEQUENTIAL_METRIC_FILES)
    if path is None:
        logging.warning("未找到正式Q2→Q3顺序基准指标表：%s。", ", ".join(SEQUENTIAL_METRIC_FILES))
        return None
    frame = _read_csv(path)
    values = None if frame is None else _metrics_from_frame(frame, ("Sequential", "Sequence", "Baseline"))
    if values is None:
        logging.warning("顺序基准表%s缺少完整六目标指标。", path.name)
        return None
    return values, path.name


def _normalised_deviation(
    values: dict[str, float],
    scaling: dict[str, tuple[float, float]],
) -> np.ndarray:
    return np.asarray(
        [max((values[metric] - scaling[metric][0]) / scaling[metric][1], 0.0) for metric in METRICS],
        dtype=float,
    )


def _compact(value: float) -> str:
    absolute = abs(value)
    if absolute >= 1e6:
        return f"{value / 1e6:+.2f}M"
    if absolute >= 1e3:
        return f"{value / 1e3:+.2f}k"
    return f"{value:+.3g}"


def _load_dispatch(path: Path) -> pd.DataFrame | None:
    frame = _read_csv(path)
    if frame is None:
        return None
    hour_column = _find_column(frame, ("Hour",))
    region_column = _find_column(frame, ("Region",))
    if hour_column is None or region_column is None:
        logging.warning("%s缺少Hour或Region字段。", path.name)
        return None
    frame = frame.copy()
    frame["_Hour"] = pd.to_numeric(frame[hour_column], errors="coerce")
    frame["_Region"] = frame[region_column].astype(str)
    frame = frame.loc[frame["_Hour"].between(0, MAIN_END_HOUR - 1)].copy()
    return frame


def _dispatch_column(frame: pd.DataFrame, aliases: tuple[str, ...]) -> str | None:
    return _find_column(frame, aliases)


def _dispatch_aggregate(frame: pd.DataFrame) -> dict[str, float] | None:
    columns = {
        "direct": ("RenewableDirectUse_MW",),
        "storage": ("RenewableCharge_MW",),
        "export": ("GridSell_MW", "RenewableExport_MW"),
        "curtailment": ("RenewableCurtailment_MW",),
        "available": ("AvailableRenewable_MW",),
        "purchase": ("GridPurchase_MW",),
    }
    resolved = {key: _dispatch_column(frame, aliases) for key, aliases in columns.items()}
    required = [key for key in ("direct", "storage", "export", "curtailment", "available", "purchase") if resolved[key] is None]
    if required:
        logging.warning("能源轨迹缺少字段：%s。", required)
        return None
    numeric = frame.copy()
    for column in resolved.values():
        numeric[column] = pd.to_numeric(numeric[column], errors="coerce")
    if numeric[list(resolved.values())].isna().any().any():
        logging.warning("能源轨迹存在无法转为数值的累计字段。")
        return None
    export = numeric[resolved["export"]]
    purchase = numeric[resolved["purchase"]]
    net_column = _dispatch_column(frame, ("NetGridImport_MW",))
    if net_column is None:
        net = purchase - export
    else:
        net = pd.to_numeric(numeric[net_column], errors="coerce")
    if net.isna().any():
        return None
    peak = float(pd.DataFrame({"Region": numeric["_Region"], "Net": net}).groupby("Region", observed=True)["Net"].max().clip(lower=0.0).sum())
    available_total = float(numeric[resolved["available"]].sum())
    curtailment_total = float(numeric[resolved["curtailment"]].sum())
    cost_column = _dispatch_column(frame, ("OperatingCost_CNY",))
    if cost_column is not None:
        cost = float(pd.to_numeric(numeric[cost_column], errors="coerce").sum())
    else:
        price_column = _dispatch_column(frame, ("ElectricityPrice_CNY_per_MWh",))
        sell_price_column = _dispatch_column(frame, ("SellPrice_CNY_per_MWh",))
        if price_column is None or sell_price_column is None:
            cost = float("nan")
        else:
            cost = float(
                (
                    pd.to_numeric(numeric[price_column], errors="coerce") * purchase
                    - pd.to_numeric(numeric[sell_price_column], errors="coerce") * export
                ).sum()
            )
    carbon_column = _dispatch_column(frame, ("CarbonEmission_tCO2",))
    if carbon_column is not None:
        carbon = float(pd.to_numeric(numeric[carbon_column], errors="coerce").sum())
    else:
        intensity_column = _dispatch_column(frame, ("CarbonIntensity_tCO2_per_MWh",))
        carbon = float(
            (
                pd.to_numeric(numeric[intensity_column], errors="coerce") * purchase
            ).sum()
        ) if intensity_column is not None else float("nan")
    charge_column = _dispatch_column(frame, ("ChargePower_MW",))
    grid_charge_column = _dispatch_column(frame, ("GridCharge_MW",))
    discharge_column = _dispatch_column(frame, ("DischargePower_MW",))
    throughput = float("nan")
    if charge_column is not None and discharge_column is not None:
        charge = pd.to_numeric(numeric[charge_column], errors="coerce")
        if grid_charge_column is not None:
            charge = charge.where(charge.notna(), 0.0)
            charge = charge + pd.to_numeric(numeric[grid_charge_column], errors="coerce").fillna(0.0)
        throughput = float((charge + pd.to_numeric(numeric[discharge_column], errors="coerce")).sum())
    return {
        "direct": float(numeric[resolved["direct"]].sum()),
        "storage": float(numeric[resolved["storage"]].sum()),
        "export": float(numeric[resolved["export"]].sum()),
        "curtailment": curtailment_total,
        "available": available_total,
        "Cost": cost,
        "Carbon": carbon,
        "Utilization": 1.0 - curtailment_total / available_total if available_total > 1e-12 else float("nan"),
        "Peak": peak,
        "throughput": throughput,
    }


SEQUENTIAL_DISPATCH_FILES = (
    "q4_sequential_region_hour_dispatch.csv",
    "q4_sequential_dispatch.csv",
    "q4_sequential_energy_profile.csv",
    "q4_sequence_region_hour_dispatch.csv",
)


def _load_sequential_dispatch() -> tuple[pd.DataFrame, str] | None:
    path = _first_existing(SEQUENTIAL_DISPATCH_FILES)
    if path is None:
        logging.warning("未找到正式Q2→Q3顺序能源轨迹表：%s。", ", ".join(SEQUENTIAL_DISPATCH_FILES))
        return None
    frame = _load_dispatch(path)
    if frame is None:
        return None
    return frame, path.name


def plot_group1_joint_optimization_results() -> bool:
    q4_values = _load_q4_objective_metrics()
    scaling = _load_scaling()
    sequential_values = _load_sequential_metrics()
    q4_dispatch = _load_dispatch(TABLES_DIR / "q4_region_hour_dispatch.csv")
    sequential_dispatch = _load_sequential_dispatch()

    figure, axes = plt.subplots(1, 2, figsize=(7.35, 3.75), gridspec_kw={"width_ratios": [1.04, 0.96]})
    figure.subplots_adjust(left=0.08, right=0.98, bottom=0.22, top=0.88, wspace=0.36)
    ax_metrics, ax_energy = axes

    if q4_values is None or scaling is None or sequential_values is None:
        _validation_placeholder(
            ax_metrics,
            "六目标顺序对照待补",
            "需要q4_sequential_objective_summary.csv\n当前仅有Q4JointRolling与Q4定标表，未用Q3固定附件基准替代",
        )
    else:
        seq_d = _normalised_deviation(sequential_values[0], scaling)
        q4_d = _normalised_deviation(q4_values, scaling)
        x = np.arange(len(METRICS), dtype=float)
        width = 0.34
        ax_metrics.bar(x - width / 2, seq_d, width, color=PALETTE["series_gold"], label="Q2→Q3顺序基准", edgecolor=PALETTE["text"], linewidth=0.35)
        ax_metrics.bar(x + width / 2, q4_d, width, color=PALETTE["series_blue"], label="Q4联合", edgecolor=PALETTE["text"], linewidth=0.35)
        for values, offset in ((seq_d, -width / 2), (q4_d, width / 2)):
            for index, value in enumerate(values):
                ax_metrics.text(index + offset, value + max(float(np.nanmax(np.r_[seq_d, q4_d])), 0.08) * 0.025, f"{value:.2g}", ha="center", va="bottom", fontsize=5.8, color=PALETTE["text"])
        z_seq = float(np.max(seq_d))
        z_q4 = float(np.max(q4_d))
        ax_metrics.axhline(z_seq, color=PALETTE["series_gold"], linestyle="--", linewidth=0.9, label=r"$z^{SEQ}$")
        ax_metrics.axhline(z_q4, color=PALETTE["series_blue"], linestyle=":", linewidth=1.0, label=r"$z^{Q4}$")
        if z_seq > 1e-12:
            change = (z_seq - z_q4) / z_seq
            message = f"最大偏离：{z_seq:.3g} → {z_q4:.3g}\n变化：{change:+.1%}"
        else:
            message = f"z_SEQ={z_seq:.3g}\nz_Q4={z_q4:.3g}"
        ax_metrics.text(0.98, 0.96, message, transform=ax_metrics.transAxes, ha="right", va="top", fontsize=6.5, bbox={"boxstyle": "round,pad=0.25", "facecolor": PALETTE["white"], "edgecolor": PALETTE["grid"], "linewidth": 0.6})
        ax_metrics.set_xticks(x, [METRIC_LABELS[metric] for metric in METRICS])
        ax_metrics.set_xlabel("六项目标")
        ax_metrics.set_ylabel(r"标准化偏离 $d_m$")
        ax_metrics.set_title("顺序基准与Q4联合优化")
        _style_axis(ax_metrics, "y")
        _legend(ax_metrics, loc="upper left", ncol=2, columnspacing=0.8, handletextpad=0.4)
    _panel_caption(ax_metrics, "(a) 六目标标准化偏离与最大偏离线")

    if q4_dispatch is None or sequential_dispatch is None:
        _validation_placeholder(
            ax_energy,
            "能源侧顺序对照待补",
            "需要q4_sequential_region_hour_dispatch.csv\n当前Q4能源轨迹可读，但不能用Q3固定附件基准拼接顺序方案",
        )
    else:
        q4_energy = _dispatch_aggregate(q4_dispatch)
        seq_energy = _dispatch_aggregate(sequential_dispatch[0])
        if q4_energy is None or seq_energy is None:
            _validation_placeholder(ax_energy, "能源侧字段待补", "顺序与Q4轨迹需同时包含直接消纳、储能、外送、弃电字段")
        else:
            keys = ("direct", "storage", "export", "curtailment")
            labels = ("直接消纳", "进入储能", "新能源外送", "弃新能源")
            delta = np.asarray([q4_energy[key] - seq_energy[key] for key in keys], dtype=float)
            x = np.arange(len(keys), dtype=float)
            colors = [PALETTE["series_blue"] if value >= 0 else PALETTE["series_orange"] for value in delta]
            ax_energy.bar(x, delta, color=colors, edgecolor=PALETTE["text"], linewidth=0.4)
            ax_energy.axhline(0, color=PALETTE["text"], linewidth=0.75)
            bound = max(float(np.max(np.abs(delta))), 1.0)
            for index, value in enumerate(delta):
                ax_energy.text(index, value + (0.035 * bound if value >= 0 else -0.035 * bound), _compact(float(value)), ha="center", va="bottom" if value >= 0 else "top", fontsize=6.2)
            callout = (
                f"ΔC={_compact(q4_energy['Cost'] - seq_energy['Cost'])} CNY\n"
                f"ΔU={(q4_energy['Utilization'] - seq_energy['Utilization']) * 100:+.2f} pp\n"
                f"ΔP={_compact(q4_energy['Peak'] - seq_energy['Peak'])} MW\n"
                f"Δ吞吐={_compact(q4_energy['throughput'] - seq_energy['throughput'])} MWh"
            )
            ax_energy.text(0.98, 0.96, callout, transform=ax_energy.transAxes, ha="right", va="top", fontsize=6.2, bbox={"boxstyle": "round,pad=0.25", "facecolor": PALETTE["white"], "edgecolor": PALETTE["grid"], "linewidth": 0.6})
            ax_energy.set_xticks(x, labels, rotation=18, ha="right")
            ax_energy.set_ylabel("累计变化（Q4−顺序） / MWh")
            ax_energy.set_title("新能源消纳与储能结构变化")
            _style_axis(ax_energy, "y")
    _panel_caption(ax_energy, "(b) 能源侧累计变化与协同摘要")
    return _save(figure, "q4_group1_joint_optimization_results")


def _canonical_scenario_metric(value: object) -> tuple[str, bool] | None:
    token = _norm_token(value)
    if token in {"cost", "operatingcost", "operatingcostcny", "c"}:
        return "Cost", False
    if token in {"carbon", "carbonemission", "carbonemissiontco2", "e"}:
        return "Carbon", False
    if token in {"latency", "meannetworklatency", "meannetworklatencyms", "l"}:
        return "Latency", False
    if token in {"qos", "servicequality", "servicequalityscore"}:
        return "QoS", False
    if token in {"j", "serviceloss", "servicequalityloss"}:
        return "QoS", True
    if token in {"utilization", "renewableutilization", "renewableutilizationrate", "u"}:
        return "Utilization", False
    if token in {"renewableunusedrate", "q"}:
        return "Utilization", True
    if token in {"peak", "peaknetgridimport", "peaknetgridimportmw", "p"}:
        return "Peak", False
    return None


def _scenario_table(path: Path) -> tuple[pd.DataFrame, str] | None:
    frame = _read_csv(path)
    if frame is None:
        return None
    scenario_column = _find_column(frame, ("Scenario", "ScenarioName", "Case", "Name"))
    if scenario_column is None:
        logging.warning("%s缺少Scenario字段。", path.name)
        return None
    metric_column = _find_column(frame, ("Metric", "Objective", "Indicator"))
    value_column = _find_column(frame, ("Value", "MetricValue", "Result", "ObjectiveValue"))
    records: list[dict[str, object]] = []
    if metric_column is not None and value_column is not None:
        for row in frame.itertuples(index=False):
            canonical = _canonical_scenario_metric(getattr(row, metric_column))
            if canonical is None:
                continue
            metric, reverse = canonical
            try:
                value = float(getattr(row, value_column))
            except (TypeError, ValueError):
                continue
            if reverse:
                value = 1.0 - value
            if np.isfinite(value):
                records.append({"Scenario": str(getattr(row, scenario_column)), "Metric": metric, "Value": value})
    else:
        wide_aliases = {
            "Cost": (("Cost", "OperatingCost_CNY", "C"), False),
            "Carbon": (("Carbon", "CarbonEmission_tCO2", "E"), False),
            "Latency": (("Latency", "MeanNetworkLatency_ms", "L"), False),
            "QoS": (("QoS", "ServiceQuality", "J"), False),
            "Utilization": (("RenewableUtilizationRate", "RenewableUtilization", "U", "RenewableUnusedRate", "Q"), False),
            "Peak": (("Peak", "PeakNetGridImport_MW", "P"), False),
        }
        for row in frame.itertuples(index=False):
            record: dict[str, object] = {"Scenario": str(getattr(row, scenario_column))}
            for metric, (aliases, _) in wide_aliases.items():
                column = _find_column(frame, aliases)
                if column is None:
                    continue
                try:
                    value = float(getattr(row, column))
                except (TypeError, ValueError):
                    continue
                if not np.isfinite(value):
                    continue
                token = _norm_token(column)
                if metric == "QoS" and token in {"j", "serviceloss", "servicequalityloss"}:
                    value = 1.0 - value
                if metric == "Utilization" and token in {"renewableunusedrate", "q"}:
                    value = 1.0 - value
                record[metric] = value
            records.append(record)
    if not records:
        return None
    result = pd.DataFrame(records)
    result["Value"] = pd.to_numeric(result["Value"], errors="coerce") if "Value" in result else np.nan
    if "Metric" in result:
        result = result.dropna(subset=["Value"])
        wide = result.pivot_table(index="Scenario", columns="Metric", values="Value", aggfunc="mean")
    else:
        wide = result.set_index("Scenario")
    missing = [metric for metric in SCENARIO_METRICS if metric not in wide.columns]
    if missing:
        logging.warning("情景表%s缺少指标：%s。", path.name, missing)
        return None
    wide = wide.loc[:, list(SCENARIO_METRICS)].dropna(how="any")
    if wide.empty:
        return None
    labels = wide.index.astype(str)
    baseline = next((label for label in labels if any(token in label.lower() for token in ("base", "baseline", "default", "基准", "默认"))), None)
    if baseline is None:
        logging.warning("情景表%s未标出基准情景，拒绝擅自用第一行充当基准。", path.name)
        return None
    return wide, str(baseline)


SCENARIO_FILES = (
    "q4_scenario_metrics.csv",
    "q4_scenarios.csv",
    "q4_scenario_results.csv",
    "q4_scenario_summary.csv",
)


def _load_scenarios() -> tuple[pd.DataFrame, str, str] | None:
    path = _first_existing(SCENARIO_FILES)
    if path is None:
        logging.warning("未找到Q4情景结果表：%s。", ", ".join(SCENARIO_FILES))
        return None
    parsed = _scenario_table(path)
    return None if parsed is None else (parsed[0], parsed[1], path.name)


def _format_change(value: float, mode: str) -> str:
    if not np.isfinite(value):
        return "—"
    if mode == "pp":
        return f"{value * 100:+.1f}pp"
    if mode == "relative":
        return f"{value * 100:+.1f}%"
    return f"{value:+.3g}"


def plot_group2_scenario_response() -> bool:
    scenarios = _load_scenarios()
    figure, axis = plt.subplots(figsize=(7.15, 3.65))
    figure.subplots_adjust(left=0.15, right=0.87, bottom=0.28, top=0.86)
    if scenarios is None:
        _validation_placeholder(
            axis,
            "Q4情景响应待补",
            "需要q4_scenario_metrics.csv（含基准、碳约束、电价、新能源波动情景）\n当前Q4模型输出目录没有情景结果表，未虚构λ或情景数",
        )
        _panel_caption(axis, "Q4三类外生机制下的策略响应矩阵")
        return _save(figure, "q4_group2_scenario_response")

    wide, baseline, source_name = scenarios
    base_values = wide.loc[baseline]
    changes = np.full((len(wide), len(SCENARIO_METRICS)), np.nan, dtype=float)
    modes: list[str] = []
    for column_index, metric in enumerate(SCENARIO_METRICS):
        base = float(base_values[metric])
        if metric in {"QoS", "Utilization"}:
            modes.append("pp")
        elif abs(base) <= 1e-12:
            modes.append("absolute")
        else:
            modes.append("relative")
        for row_index, value in enumerate(wide[metric].to_numpy(dtype=float)):
            changes[row_index, column_index] = value - base if modes[-1] != "relative" else (value - base) / abs(base)
    finite = changes[np.isfinite(changes)]
    limit = max(float(np.max(np.abs(finite))) if finite.size else 1.0, 1e-8)
    norm = TwoSlopeNorm(vmin=-limit, vcenter=0.0, vmax=limit)
    image = axis.imshow(changes, cmap=SCENARIO_CMAP, norm=norm, aspect="auto")
    axis.set_xticks(np.arange(len(SCENARIO_METRICS)), [SCENARIO_LABELS[metric] for metric in SCENARIO_METRICS])
    axis.set_yticks(np.arange(len(wide)), wide.index.astype(str))
    axis.set_xlabel("最终指标；QoS=1−J，U=1−Q")
    axis.set_title(f"不同机制情景相对基准的响应（来源：{source_name}）")
    for row_index in range(changes.shape[0]):
        for column_index in range(changes.shape[1]):
            text = _format_change(changes[row_index, column_index], modes[column_index])
            color = PALETTE["white"] if abs(changes[row_index, column_index]) > limit * 0.54 else PALETTE["text"]
            axis.text(column_index, row_index, text, ha="center", va="center", fontsize=6.3, color=color)
    axis.set_xticks(np.arange(-0.5, len(SCENARIO_METRICS), 1), minor=True)
    axis.set_yticks(np.arange(-0.5, len(wide), 1), minor=True)
    axis.grid(which="minor", color=PALETTE["white"], linewidth=1.0)
    axis.tick_params(which="minor", bottom=False, left=False)
    _style_axis(axis, "none")
    colorbar = figure.colorbar(image, ax=axis, fraction=0.035, pad=0.035)
    colorbar.set_label("相对变化；比例/百分点/零基准绝对差", color=PALETTE["text"], fontsize=7)
    colorbar.ax.tick_params(colors=PALETTE["text"], labelsize=6.5)
    colorbar.outline.set_edgecolor(PALETTE["text"])
    _panel_caption(axis, "情景—指标响应矩阵；正值表示相对基准上升", y=-0.27)
    return _save(figure, "q4_group2_scenario_response")


WINDOW_PAIR_FILES = (
    "q4_mh_ref_comparison.csv",
    "q4_window_mh_ref.csv",
    "q4_window_validation.csv",
    "q4_solver_comparison.csv",
    "q4_exact_window_comparison.csv",
    "q4_reference_comparison.csv",
)


def _window_pair(path: Path) -> pd.DataFrame | None:
    frame = _read_csv(path)
    if frame is None:
        return None
    window_column = _find_column(frame, ("WindowStart", "Window", "Tau", "WindowID"))
    mh_z_column = _find_column(frame, ("Z_MH", "ZMH", "MH_Z", "MHObjective", "HeuristicObjective", "ZHeuristic"))
    ref_z_column = _find_column(frame, ("Z_REF", "ZREF", "REF_Z", "REFObjective", "ReferenceObjective", "ZExact", "ExactObjective"))
    if mh_z_column is None or ref_z_column is None:
        logging.warning("%s缺少MH/REF目标值字段。", path.name)
        return None
    result = pd.DataFrame({
        "Window": pd.to_numeric(frame[window_column], errors="coerce") if window_column is not None else np.arange(len(frame)),
        "Z_MH": pd.to_numeric(frame[mh_z_column], errors="coerce"),
        "Z_REF": pd.to_numeric(frame[ref_z_column], errors="coerce"),
    })
    mh_time_column = _find_column(frame, ("Time_MH", "MHTime", "ElapsedMH", "HeuristicTime"))
    ref_time_column = _find_column(frame, ("Time_REF", "REFTime", "ElapsedREF", "ReferenceTime", "ExactTime"))
    lb_column = _find_column(frame, ("LB", "LowerBound", "ReferenceLowerBound"))
    result["Time_MH"] = pd.to_numeric(frame[mh_time_column], errors="coerce") if mh_time_column is not None else np.nan
    result["Time_REF"] = pd.to_numeric(frame[ref_time_column], errors="coerce") if ref_time_column is not None else np.nan
    result["LB"] = pd.to_numeric(frame[lb_column], errors="coerce") if lb_column is not None else np.nan
    result = result.replace([np.inf, -np.inf], np.nan).dropna(subset=["Z_MH", "Z_REF"])
    result = result.loc[result["Z_REF"] > 1e-12].reset_index(drop=True)
    if len(result) < 2:
        return None
    return result


def _load_window_pair() -> tuple[pd.DataFrame, str] | None:
    path = _first_existing(WINDOW_PAIR_FILES)
    if path is None:
        logging.warning("未找到MH/REF窗口对照表：%s。", ", ".join(WINDOW_PAIR_FILES))
        return None
    pair = _window_pair(path)
    return None if pair is None else (pair, path.name)


def _select_representative_windows(pair: pd.DataFrame) -> pd.DataFrame:
    times = pair["Time_MH"]
    if times.notna().any():
        median_time = float(times.median())
        ordinary_index = (times - median_time).abs().idxmin()
        difficult_index = times.idxmax()
    else:
        ordinary_index = int((pair["Window"] - pair["Window"].median()).abs().idxmin())
        difficult_index = int(pair["Window"].idxmax())
    selected = pair.loc[[ordinary_index, difficult_index]].copy()
    selected["Kind"] = ["普通窗口", "困难窗口"]
    if ordinary_index == difficult_index:
        selected = pair.loc[[ordinary_index]].copy()
        selected["Kind"] = ["代表窗口"]
    return selected


def _load_soc_trajectory() -> tuple[pd.DataFrame, pd.DataFrame] | None:
    dispatch = _read_table("q4_region_hour_dispatch.csv")
    storage = _read_csv(SHARED_DIR / "storage_params.csv", ("Region", "StorageCapacity_MWh", "MinSOC_MWh", "InitialSOC_MWh"))
    if dispatch is None or storage is None:
        return None
    required = {"Hour", "Region", "SOCStart_MWh", "SOCEnd_MWh"}
    if not required.issubset(dispatch.columns):
        logging.warning("Q4逐时调度缺少SOC字段。")
        return None
    rows: list[dict[str, float | str]] = []
    dispatch = _numeric(dispatch, ["Hour", "SOCStart_MWh", "SOCEnd_MWh"])
    storage = _numeric(storage, ["StorageCapacity_MWh", "MinSOC_MWh", "InitialSOC_MWh"])
    storage = storage.set_index("Region")
    regions = [region for region in REGION_ORDER if region in storage.index and region in set(dispatch["Region"].astype(str))]
    if len(regions) < 1:
        return None
    for region in regions:
        local = dispatch.loc[dispatch["Region"].astype(str).eq(region)].sort_values("Hour", kind="stable")
        local = local.loc[local["Hour"].between(0, MAIN_END_HOUR - 1)]
        if len(local) != MAIN_END_HOUR or not np.array_equal(local["Hour"].to_numpy(dtype=int), np.arange(MAIN_END_HOUR)):
            logging.warning("区域%s的SOC轨迹没有完整覆盖0--2405小时。", region)
            return None
        capacity = float(storage.loc[region, "StorageCapacity_MWh"])
        minimum = float(storage.loc[region, "MinSOC_MWh"])
        initial = float(storage.loc[region, "InitialSOC_MWh"])
        denominator = capacity - minimum
        if denominator <= 0:
            logging.warning("区域%s的SOC容量差无效。", region)
            return None
        soc = np.r_[float(local.iloc[0]["SOCStart_MWh"]), local["SOCEnd_MWh"].to_numpy(dtype=float)]
        norm = (soc - minimum) / denominator
        for hour, value in enumerate(norm):
            rows.append({"Region": region, "Hour": float(hour), "SOCNorm": float(value), "InitialNorm": (initial - minimum) / denominator})
    return pd.DataFrame(rows), storage.reset_index()


def plot_group3_model_validation() -> bool:
    window_pair = _load_window_pair()
    soc_data = _load_soc_trajectory()
    figure, axes = plt.subplots(1, 2, figsize=(7.35, 3.85), gridspec_kw={"width_ratios": [0.92, 1.45]})
    figure.subplots_adjust(left=0.08, right=0.98, bottom=0.22, top=0.87, wspace=0.34)
    ax_pair, ax_soc = axes

    if window_pair is None:
        _validation_placeholder(
            ax_pair,
            "MH/REF窗口对照待补",
            "需要q4_mh_ref_comparison.csv\n当前q4_window_solver.csv仅含滚动求解日志，不能充当300 s完整MILP参考值",
        )
    else:
        pair, source_name = window_pair
        selected = _select_representative_windows(pair)
        x = np.arange(len(selected), dtype=float)
        ratio = selected["Z_MH"].to_numpy(dtype=float) / selected["Z_REF"].to_numpy(dtype=float)
        width = 0.32
        ax_pair.bar(x - width / 2, np.ones(len(selected)), width, color=PALETTE["series_gold"], label=r"$Z^{REF}$", edgecolor=PALETTE["text"], linewidth=0.35)
        ax_pair.bar(x + width / 2, ratio, width, color=PALETTE["series_blue"], label=r"$Z^{MH}/Z^{REF}$", edgecolor=PALETTE["text"], linewidth=0.35)
        for index, row in enumerate(selected.itertuples(index=False)):
            time_mh = f"{row.Time_MH:.1f}s" if np.isfinite(row.Time_MH) else "—"
            time_ref = f"{row.Time_REF:.1f}s" if np.isfinite(row.Time_REF) else "—"
            speedup = row.Time_REF / row.Time_MH if np.isfinite(row.Time_REF) and np.isfinite(row.Time_MH) and row.Time_MH > 1e-12 else np.nan
            text = f"MH {time_mh}\nREF {time_ref}"
            if np.isfinite(speedup):
                text += f"\n{speedup:.1f}×"
            ax_pair.text(index + width / 2, max(1.0, ratio[index]) + 0.04, text, ha="center", va="bottom", fontsize=5.8)
        ax_pair.set_xticks(x, selected["Kind"])
        ax_pair.set_ylabel(r"归一化目标 $Z^{MH}/Z^{REF}$")
        ax_pair.set_title(f"普通/困难代表窗口（{source_name}）")
        ax_pair.axhline(1.0, color=PALETTE["reference"], linestyle="--", linewidth=0.8)
        _style_axis(ax_pair, "y")
        _legend(ax_pair, loc="upper left")
    _panel_caption(ax_pair, "(a) 数学启发式与完整MILP参考")

    if soc_data is None:
        _validation_placeholder(ax_soc, "SOC轨迹待补", "需要q4_region_hour_dispatch.csv与共享storage_params.csv")
    else:
        trajectory, _storage = soc_data
        for region in REGION_ORDER:
            local = trajectory.loc[trajectory["Region"].eq(region)]
            if local.empty:
                continue
            ax_soc.plot(local["Hour"], local["SOCNorm"], linewidth=0.85, color=REGION_COLORS[region], label=region.replace("Region", "区域"))
            initial = float(local["InitialNorm"].iloc[0])
            ax_soc.scatter([0], [initial], s=19, facecolor=PALETTE["white"], edgecolor=REGION_COLORS[region], linewidth=0.85, zorder=4)
            terminal = float(local.loc[local["Hour"].eq(MAIN_END_HOUR), "SOCNorm"].iloc[0])
            ax_soc.scatter([MAIN_END_HOUR], [terminal], s=19, facecolor=REGION_COLORS[region], edgecolor=PALETTE["text"], linewidth=0.45, zorder=4)
        terminal_ok = True
        for region in REGION_ORDER:
            local = trajectory.loc[trajectory["Region"].eq(region)]
            if local.empty:
                continue
            terminal_ok = terminal_ok and bool(float(local.loc[local["Hour"].eq(MAIN_END_HOUR), "SOCNorm"].iloc[0]) >= float(local["InitialNorm"].iloc[0]) - 1e-6)
        ax_soc.axhline(0.0, color=PALETTE["reference"], linestyle="--", linewidth=0.8, label="SOC下界")
        ax_soc.axhline(1.0, color=PALETTE["reference"], linestyle=":", linewidth=0.9, label="SOC上界")
        ax_soc.axvline(MAIN_END_HOUR, color=PALETTE["neutral"], linestyle="--", linewidth=0.6)
        ax_soc.text(0.98, 0.12, r"$S_{r,2406}\geq InitialSOC_r$" + ("：全部满足" if terminal_ok else "：存在不满足"), transform=ax_soc.transAxes, ha="right", va="bottom", fontsize=6.5, color=PALETTE["text"], bbox={"boxstyle": "round,pad=0.25", "facecolor": PALETTE["white"], "edgecolor": PALETTE["grid"], "linewidth": 0.6})
        ax_soc.set_xlim(0, MAIN_END_HOUR)
        ax_soc.set_ylim(-0.035, 1.035)
        ax_soc.set_xlabel("时段 t / h")
        ax_soc.set_ylabel(r"归一化储能状态 $SOC^{norm}_{rt}$")
        ax_soc.set_title("全时域SOC可行性与终端恢复")
        _style_axis(ax_soc, "both")
        _legend(ax_soc, loc="upper left", bbox_to_anchor=(0.02, 1.01), ncol=4, columnspacing=0.7, handletextpad=0.35)
    _panel_caption(ax_soc, "(b) 六区域SOC轨迹与终端恢复")
    return _save(figure, "q4_group3_model_validation")


def main() -> int:
    _configure_style()
    FIGURES_DIR.mkdir(parents=True, exist_ok=True)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)s | %(message)s", force=True)
    logging.getLogger("fontTools").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)
    results = {
        "group1": plot_group1_joint_optimization_results(),
        "group2": plot_group2_scenario_response(),
        "group3": plot_group3_model_validation(),
    }
    logging.info("Q4绘图完成状态：%s。", results)
    return 0 if all(results.values()) else 1


if __name__ == "__main__":
    raise SystemExit(main())
